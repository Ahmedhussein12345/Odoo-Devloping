# -*- coding: utf-8 -*-
from datetime import timedelta
from odoo import models, fields, api
from odoo.exceptions import ValidationError

class Course(models.Model):
    _name = 'openacademy.course'
    name = fields.Char(string='Title',required=True)
    description = fields.Text()
    responsible_id = fields.Many2one('res.users',ondelete='set null',string="Responsible",index=True)
    session_ids = fields.One2many(
        'openacademy.session', 'course_id', string="Sessions")

class Session(models.Model):
    _name= 'openacademy.session'
    name = fields.Char(string='Title',required=True)
    
    start_date = fields.Date(default=fields.Date.today)
    duration = fields.Float(digits=(6,2),help="Duration in days")
    seats = fields.Integer(string="Number of seats")
    instructor_id = fields.Many2one('res.partner', string="Instructor",
        domain=['|', ('instructor', '=', True),
                     ('category_id.name', 'ilike', "Teacher")])
    course_id = fields.Many2one('openacademy.course',string="Course",ondelete='cascade',required=True)
    taken_seats = fields.Float(string="Taken seats", compute='_taken_seats')
    end_date = fields.Date(string="End Date", store=True,
        compute='_get_end_date', inverse='_set_end_date')
    hours = fields.Float(string="Duration in hours",
                         compute='_get_hours', inverse='_set_hours')
    
    attendees_count = fields.Integer(
        string="Attendees count", compute='_get_attendees_count', store=True)

    color = fields.Integer()

    state = fields.Selection([
        ('draft', "Draft"),
        ('confirmed', "Confirmed"),
        ('done', "Done"),
    ], default='draft')


    @api.depends('seats')
    def _taken_seats(self):
        for r in self:
            if not r.seats:
                r.taken_seats = 0.0
            else:
                r.taken_seats = 100.0 * r.seats/50

    @api.onchange('seats')
    def _verify_valid_seats(self):
        if self.seats < 0:
            self.seats=-1*self.seats
            return {
                'warning': {
                    'title': "Incorrect 'seats' value ( My Customer )",
                    'message': "The number of available seats may not be negative !!!",
                },
            }

        if self.seats > 50:
            return {
                'warning': {
                    'title': "Incorrect 'seats' value ( My Customer )",
                    'message': "The number of available seats Not Available !!!",
                },
            }
    @api.depends('start_date', 'duration')
    def _get_end_date(self):
        for r in self:
            if not (r.start_date and r.duration):
                r.end_date = r.start_date
                continue

            # Add duration to start_date, but: Monday + 5 days = Saturday, so
            # subtract one second to get on Friday instead
            start = fields.Datetime.from_string(r.start_date)
            duration = timedelta(days=r.duration, seconds=-1)
            r.end_date = start + duration

    def _set_end_date(self):
        for r in self:
            if not (r.start_date and r.end_date):
                continue

            # Compute the difference between dates, but: Friday - Monday = 4 days,
            # so add one day to get 5 days instead
            start_date = fields.Datetime.from_string(r.start_date)
            end_date = fields.Datetime.from_string(r.end_date)
            r.duration = (end_date - start_date).days + 1
    @api.depends('duration')
    def _get_hours(self):
        for r in self:
            r.hours = r.duration * 24

    def _set_hours(self):
        for r in self:
            r.duration = r.hours / 24

    @api.depends('duration')
    def _get_attendees_count(self):
        for r in self:
            r.attendees_count = self.duration

    
    @api.multi
    def action_draft(self):
        self.state = 'draft'

    @api.multi
    def action_confirm(self):
        self.state = 'confirmed'

    @api.multi
    def action_done(self):
        self.state = 'done'


class Partner(models.Model):
    _inherit = 'res.partner'
    instructor = fields.Boolean("Instructor", default=False)
    

    






