# -*- coding: utf-8 -*-

from odoo import models, fields


class RejectRequest(models.TransientModel):
    _name = 'reject.request'
    reason = fields.Text('Reason', required=True)

    def action_confirm(self):
        active_id = self.env.context.get("active_id")
        pr = self.env['purchase.request'].browse(active_id)
        pr.write({
            'rejection_reason':self.reason,
            'state':'reject',
        })
































