# -*- coding: utf-8 -*-
{
    'name': "Mobile Management For Meter Shaban ",

    'summary': """
        Mobile Management Program """,

    'description': """
        Mobile Management Program For shaban by Ahmed Hussein
    """,

    'author': "Ahmed Hussein",
    'website': "https://www.facebook.com/engineerahmedhusseinhassanin",

    'category': 'Uncategorized',
    'version': '0.1',

    
    'depends': ['base'],

   
    'data': [
        'security/security.xml',
        'security/ir.model.access.csv',
        'views/customer.xml',
        'views/report_customer.xml',
        'views/report_one_customer.xml',
        'views/report_month_pay.xml',
        
        
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
    'installable':True,
    'application':True,
    'images': ['static/description/icon.png'],
    
}