# -*- coding: utf-8 -*-
{
    'name': "TASK ODOO 13  ZAD SOLUTIONS COMPANY",

    'summary': """
        ASK ODOO 13  ZAD SOLUTIONS COMPANY
        """,

    'description': """
       ASK ODOO 13  ZAD SOLUTIONS COMPANY
    """,

    'author': "ENGINEER AHMED",
    'website': "https://www.facebook.com/engineerahmedhusseinhassanin",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base', 'purchase' , 'mail'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'wizards/reject_request.xml',
        'data/email_template.xml',
        'views/views.xml',
        'views/templates.xml',

    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/demo.xml',
    ],
}
