from datetime import timedelta
from odoo import models ,fields,api,_
from odoo.exceptions import ValidationError
class MobileCustomer(models.Model):
    _name = 'mobile.customer'
    #_inherit=['mail.thread','mail.activity.mixin']
    _description = "Mobile Management"
    name = fields.Char(string="Customer Name", required=True)
    mobile=fields.Char(string="Customer Phone", required=True)
    mobile_name = fields.Char(string="Mobile Name", required=True)
    buy_date=fields.Date(string="Buying Date", required=True)
    cash_price = fields.Integer(string="Cash price", required=True)
    qest_price = fields.Integer(string="Qest price", required=True)
    moqadam_money=fields.Integer(string="Starting price", required=True)
    baqy=fields.Integer(string="baqy price",compute="get_baqy",store=True)
    discount=fields.Integer(string="Discount")
    #baqy=fields.Integer(string="Baqy Money", required=True, compute='_baqy_money')
    pay_system=fields.Selection([
        ('month','Month'),
        ('weak','Weak')], default = 'month',
    )
    main_pay = fields.Integer(string="Main Pay", required=True)
   
    note=fields.Html(string="Notes", required=True)
    customer_pay= fields.One2many(
        'mobile.pay', 'name', string="Payings")

    baqy_qest = fields.Integer(string="Baqy Qest",compute="get_baqy_qest",store=True)
    is_archived = fields.Boolean(compute="get_is_archived",store=True)

    @api.multi
    @api.depends("customer_pay")
    def get_is_archived(self):
        for rec in self:
            if rec.baqy - sum(rec.customer_pay.mapped("what_pay")) == 0:
                rec.is_archived = True
            else:
                rec.is_archived = False

    @api.multi
    @api.depends("customer_pay")
    def get_baqy_qest(self):
        for rec in self:
            rec.baqy_qest = rec.baqy -  sum(rec.customer_pay.mapped("what_pay"))
    
    @api.multi
    @api.depends("qest_price")
    def get_baqy(self):
        for rec in self:
            rec.baqy = rec.qest_price 

    
    

    @api.onchange('cash_price', 'moqadam_money')
    def _verify_valid_cash_price(self):
        if self.cash_price < 0:
            return {
                'warning': {
                    'title': _("Error"),
                    'message': _("Cash Money may not be negative"),
                },
            }
        if self.moqadam_money < 0:
            return {
                'warning': {
                    'title': _("Error"),
                    'message': _("Moqadam Money may not be negative"),
                },
            }

       

    


   

   
  
class MobilePay(models.Model):
    _name = 'mobile.pay'
    #_inherit=['mail.thread','mail.activity.mixin']
    _description = "Mobile Management"
    name = fields.Many2one('mobile.customer',string="Customer Name", required=True)
    pay_date=fields.Date(string="Paying Date", required=True)
    what_pay = fields.Integer(string="What Pay", required=True)
    baqy=fields.Integer(string="Baqy ",compute="get_baqy",store=True)
    note=fields.Html("Notes Here")

    @api.multi
    @api.depends("name","what_pay")
    def get_baqy(self):
        pay_total = 0.0
        for res in self:
            for rec in self.env['mobile.pay'].search([("name",'=',res.name.id)]):
                pay_total += rec.what_pay

            res.baqy = res.name.baqy - pay_total 
        

      
    
    
    

   
    



    
  

    

""" class Session(models.Model):
    _name = 'openacademy.session'
    
    _description = "OpenAcademy Sessions"
    _rec_name="course_id"
    start_date = fields.Date(default=fields.Date.today)
    duration = fields.Float(digits=(6, 2), help="Duration in days")
    seats = fields.Integer(string="Number of seats")
    instructor_id = fields.Many2one('res.partner', string="Instructor",
         domain=['|', ('instructor', '=', True),
                     ('category_id.name', 'ilike', "Teacher")])
    course_id = fields.Many2one('openacademy.course',
        ondelete='cascade', string="Select Course", required=True)
    attendee_ids = fields.Many2many('res.partner', string="Attendees")
    taken_seats = fields.Float(string="Taken seats", compute='_taken_seats')
    end_date = fields.Date(string="End Date", store=True,
        compute='_get_end_date', inverse='_set_end_date')

    hours = fields.Float(string="Duration in hours",
                         compute='_get_hours', inverse='_set_hours')

    attendees_count = fields.Integer(
        string="Attendees count", compute='_get_attendees_count', store=True)

    active = fields.Boolean(default=True)
    color = fields.Integer()



    @api.depends('seats', 'attendee_ids')
    def _taken_seats(self):
        for r in self:
            if not r.seats:
                r.taken_seats = 0.0
            else:
                r.taken_seats = 100.0 * len(r.attendee_ids) / r.seats

    @api.depends('duration')
    def _get_hours(self):
        for r in self:
            r.hours = r.duration * 24

    @api.depends('attendee_ids')
    def _get_attendees_count(self):
        for r in self:
            r.attendees_count = len(r.attendee_ids)

    def _set_hours(self):
        for r in self:
            r.duration = r.hours / 24

    @api.depends('start_date', 'duration')
    def _get_end_date(self):
        for r in self:
            if not (r.start_date and r.duration):
                r.end_date = r.start_date
                continue

            # Add duration to start_date, but: Monday + 5 days = Saturday, so
            # subtract one second to get on Friday instead
            duration = timedelta(days=r.duration, seconds=-1)
            r.end_date = r.start_date + duration

    def _set_end_date(self):
        for r in self:
            if not (r.start_date and r.end_date):
                continue

            # Compute the difference between dates, but: Friday - Monday = 4 days,
            # so add one day to get 5 days instead
            r.duration = (r.end_date - r.start_date).days + 1


    @api.onchange('seats', 'attendee_ids')
    def _verify_valid_seats(self):
        if self.seats < 0:
            return {
                'warning': {
                    'title': "Incorrect 'seats' value",
                    'message': "The number of available seats may not be negative",
                },
            }
        if self.seats < len(self.attendee_ids):
            return {
                'warning': {
                    'title': "Too many attendees",
                    'message': "Increase seats or remove excess attendees",
                },
            }

    @api.constrains('instructor_id', 'attendee_ids')
    def _check_instructor_not_in_attendees(self):
        for r in self:
            if r.instructor_id and r.instructor_id in r.attendee_ids:
                raise exceptions.ValidationError("A session's instructor can't be an attendee")  """