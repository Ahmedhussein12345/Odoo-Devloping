from odoo import models, fields, api
from datetime import datetime

class PurchaseRequest(models.Model):
    _name = 'purchase.request'
    _rec_name = 'request_name'
    request_name = fields.Char(string="Request Name", required=True)
    requested_by = fields.Many2one('res.users', required= True ,string='Requested By', index=True, default=lambda self: self.env.user )
    start_date = fields.Datetime(string="Start Date", default=datetime.today())
    end_date = fields.Datetime("End Date")
    rejection_reason = fields.Text(invisible=True,string="Rejection Reason")
    orderlines = fields.One2many("order.lines", "name", string="Purchase Request Line")

    state = fields.Selection([
        ('draft', 'Draft'),
        ('to_be_approved', 'To Be Approved'),
        ('approve', 'Approve'),
        ('reject', 'Reject'),
        ('cancel', 'Cancel'),
    ], string='Status', readonly=True, default='draft')



    def action_approve(self):
        #mail_template = self.env.ref('purchase.request.email_template')
        #mail_template.send_mail(self.id, force_send=True)
        self.state = 'approve'
        print("****************************************************************")

    def action_submit_for_approval(self):
        for rec in self:
            rec.state = 'to_be_approved'

    def action_cancel(self):
        for rec in self:
            rec.state = 'to_be_approved'


    def action_reset_to_draft(self):
        for rec in self:
            rec.state = 'draft'

    def action_approve(self):
        template_id = self.env.ref('task.purchase_request_email_template').id
        template = self.env['mail.template'].browse(template_id)
        template.send_mail(self.id, force_send=True)
        self.state = 'approve'




class OrderLines(models.Model):
    _name = 'order.lines'
    name = fields.Many2one("purchase.request" , string="Request Name" )
    product_id = fields.Many2one("product.product", string="Product Name")
    description = fields.Char(string="Description" )
    quantity = fields.Float(string="Quantity" , default=1 )
    cost_price = fields.Float("Cost Price" ,readonly=True , compute="_get_cost" , store=True ,force_save="1")
    total = fields.Float(string="Total",  readonly=True , compute="_compute_total" , store=True ,force_save="1")
    # total_price = fields.Float("Total Price", readonly=True, compute="_compute_total_price", store=True, force_save="1")


    @api.onchange("product_id")
    def _get_description(self):
        for rec in self:
            self.description = '[' + str(self.product_id.default_code) + ']' + str(self.product_id.name)

    @api.depends("product_id")
    def _get_cost(self):
        for rec in self:
            self.cost_price = self.product_id.standard_price


    @api.depends("quantity" , "cost_price")
    def _compute_total(self):
        for rec in self:
            t = rec.quantity * rec.cost_price
            rec.total = t

    '''@api.depends("orderlines")
        def _compute_total_price(self):
            t = 0
            for rec in self:
                s = rec.orderlines.total
                t = t + s
            self.total_price = t '''












